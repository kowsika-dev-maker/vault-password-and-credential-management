package com.securevault.backend.repository;

import com.securevault.backend.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditLogRepository
        extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByEmailOrderByTimestampDesc(
            String email
    );
}